# nose-crow-register

## Kurulum

Eğer direk projeyi kurucaksanız tek yapmanız gereken Settings klasöründeki bir kaç dosyayı doldurmak.

```js
Settings.json ve Other.json
```
## Sıkça Sorulabilicek Sorular


### Kod Dosyalarını Nasıl Kurucam?

Tek yapmanız gereken dosyalardaki ID kısımlarını doldurmak, adonis.js'ye atılıcak bir kod yoktur.

### Sana bir sorum vardı?

[Adonis.](discord.com/users/804756856391860234) Discord hesabıma ulaşabilirsiniz, eğer ulaşamazsanız [discord.gg/serendia](https://discord.gg/serendia)'ya sorun, yol göstereceklerdir.

### Bir hata buldum?

Bana ulaşın, elimden geldiğince hızlı çözerim.

## Serendia Ailesine Sevgilerle <3
![Serendia](standard_11.gif)

